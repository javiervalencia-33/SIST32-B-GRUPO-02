
<link rel="stylesheet" href="estilomenu.css">

<ul class="menu cf">
	<li><a href="index.php">INICIO</a></li>
	<li>
		<a href="">SERVICIOS</a>
		<ul class="submenu">
			<li><a href="topografia.php">TOPOGRAFIA</a></li>
			<li><a href="supervision.php">SUPERVISION</a></li>
			<li><a href="construccion.php">CONSTRUCCION</a></li>
			<li><a href="diseño.php">DISEÑO</a></li>
		</ul>			
	</li>
	<li><a href="contactos.php">Contactanos</a></li>
	<li><a href="login.php">loguearse</a></li>
</ul>