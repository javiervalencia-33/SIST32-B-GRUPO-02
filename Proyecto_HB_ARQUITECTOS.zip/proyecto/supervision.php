<!DOCTYPE html>
<html lang="es">
<head>
	<title>HB ARQUITECTOS</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" href="misestilos2.css">
	<link rel="shortcut icon" href="imagenes/HB.jpg" type="img/x-icon">
	<script src="javascript.js">
	</script>
	<link rel="stylesheet" type="text/css" href="buttonform.css">
</head>
 
<body>
<div class="container">
	<header>
		<figure>
		<a href="index.html"><img src="imagenes/HB.jpg" title="HBarquitectos" align="landscape"></a>
		</figure>
		<footer>
		<img src="imagenes/portadaf.jpeg">
		</footer>
		<h1 align="center">SUPERVISION</h1>
	</header>
 	
<?php require_once"menu.php"?>

	<section>
	<center>
	<img src="imagenes/super1.jpeg" width="550" height="450">
	</center>
 	<center>
	
		<p>
			<b>Priorizar tu bolsillo es nuestra prioridad al momento de llevar tus sueños a la realidad, cotiza con nosotros y ten por seguro un proyecto satisfactorio y una inversión bien hecha por tu parte.</b>
			<br>
			<br>
			<big>LOS SERVICIOS DE SUPERVISION QUE OFRECEMOS SON:</big>
			<br>
				<ul>
					- <b>Supervision de obras</b>
					<br>
					- <b>Gestion de proyectos</b>
					<br>
					- <b>Presupuestos y control de materiales</b>
					<br>
					- <b>Asesoria en tramites institucionales</b>
				</ul>
			</p>
			<a class="boton_personalizado" href="contactos.php">SOLICITAR SERVICIO</a>
	</section>
	</center>
	<aside><img src="imagenes/wa.jpeg"></aside>
 
	<footer id="pie">
		<a>
		<h5>HB ARQUITECTOS&nbsp;&nbsp;&nbsp;DISEÑO,ARQUITECTURA Y CONSTRUCCIÓN &nbsp;&nbsp;&nbsp;© 2019</h5>&nbsp;&nbsp;&nbsp;&nbsp;</a><a href="https://www.facebook.com/HBarquitectos.sv/"><img src="imagenes/face.png" height="40" width="40"></a><a>&nbsp;&nbsp;&nbsp;&nbsp;
		</a><a href="https://www.instagram.com/hb_arquitectos.sv/"><img src="imagenes/insta.jpeg" height="40" width="40"></a></footer><a href="https://www.instagram.com/hb_arquitectos.sv/">
	</footer>
</div>
</body>
</html>