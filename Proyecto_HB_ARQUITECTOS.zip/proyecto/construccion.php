<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>HB ARQUITECTOS</title>
	<link rel="stylesheet" href="misestilos3.css">
	<link rel="shortcut icon" href="imagenes/HB.jpg" type="img/x-icon">
	<script src="javascript.js">
	</script>
	<link rel="stylesheet" type="text/css" href="buttonform.css">
</head>
 
<body>
<div class="container">
	<header>
		<figure>
		<a href="index.html"><img src="imagenes/HB.jpg" title="HBarquitectos" align="landscape"></a>
		</figure>
		<footer>
		<img src="imagenes/portadaf.jpeg">
		</footer>
		<h1 align="center">CONTRUCCION</h1>
	</header>
 	
<?php require_once"menu.php"?>

	<section>
	<center>
	<img src="imagenes/constru1.jpeg">
	</center>
 	<center>
	
		<p>
			<b>No dejes tus obras en las manos de cualquier persona y evitate riesgos para tu familia o clientes, cotiza con nosotros y deja que profesionales te entreguen un proyecto con todas las condiciones adecuadas.</b>
			<br>
			<br>
			<big>LOS SERVICIOS DE CONSTRUCCION QUE OFRECEMOS SON:</big>
			<br>
				<ul>
					- <b>Obra civil en general</b>
					<br>
					- <b>Stands comerciales y mobiliarios urbanos</b>
					<br>
					- <b>Aplicaciones y remodelaciones</b>
					<br>
					- <b>Habitacional, comercial y administrativo</b>
				</ul>
				<a class="boton_personalizado" href="contactos.php">SOLICITAR SERVICIO</a>
			</p>
	</section>
	</center>
	<aside><img src="imagenes/wa.jpeg"></aside>
 
	<footer id="pie">
		<a>
		<h5>HB ARQUITECTOS&nbsp;&nbsp;&nbsp;DISEÑO,ARQUITECTURA Y CONSTRUCCIÓN &nbsp;&nbsp;&nbsp;© 2019</h5>&nbsp;&nbsp;&nbsp;&nbsp;</a><a href="https://www.facebook.com/HBarquitectos.sv/"><img src="imagenes/face.png" height="40" width="40"></a><a>&nbsp;&nbsp;&nbsp;&nbsp;
		</a><a href="https://www.instagram.com/hb_arquitectos.sv/"><img src="imagenes/insta.jpeg" height="40" width="40"></a></footer><a href="https://www.instagram.com/hb_arquitectos.sv/">
	</footer>
</div>
</body>
</html>