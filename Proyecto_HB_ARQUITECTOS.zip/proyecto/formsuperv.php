<!DOCTYPE html>
<html>
<head>
	<title>SUPERVISION</title>

	<link rel="stylesheet" type="text/css" href="css_formtopo.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" href="misestilos2.css">
	<link rel="shortcut icon" href="imagenes/HB.jpg" type="img/x-icon">
	<script src="javascript.js">
	</script>

</head>
<body>
	<?php require_once"menu.php"?>

<form action="#" target="" method="get" name="formDatosPersonales">

	<label for="nombre">Nombre</label>
	<input type="text" name="nombre" id="nombre" placeholder="Escribe tu nombre"/>

	<label for="apellidos">Apellidos</label>
	<input type="text" name="apellidos" id="apellidos" placeholder="1r Apellido"/>

	<label for="telefono">Telefono</label>
	<input type="tel" name="telefono" id="telefono" placeholder="numero telefonico">

	<label for="email" />Email</label>
	<input type="email" name="email" id="email" placeholder="email" required />

	<label for="tipo_supervision">Tipo de supervision</label>
	<label>
            <input type="radio" name="tipo_supervision" value="comercial">Comercial
        </label>
      
        <label>
            <input type="radio" name="tipo_supervision" value="residencial">Residencial
        </label>
        <br>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>
            <input type="radio" name="tipo_supervision" value="industrial">Industrial
        </label><br>
        <br>

	<label for="asunto">Asunto</label>
	<input type ="text" name="asunto" id="asunto" placeholder="titular de la consulta"/>

	<label for="mensaje">Mensaje</label>
	<textarea name="mensaje" for="mensaje" placeholder="Describe brevemente lo que necesita" maxlength="500"></textarea>
	
	<input type="submit" name="enviar" value="enviar datos"/>
</form>

</body>
</html>