<!DOCTYPE html>
<html>
<head>
	<title>DISEÑO</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="stylesheet" href="misestilos3.css">
	<link rel="shortcut icon" href="imagenes/HB.jpg" type="img/x-icon">
	<script src="javascript.js">
	</script>
	<link rel="stylesheet" type="text/css" href="css_formtopo.css">
</head>
<body>
	<?php require_once"menu.php"?>

<form action="#" target="" method="get" name="formDatosPersonales">

	<label for="nombre">Nombre</label>
	<input type="text" name="nombre" id="nombre" placeholder="Escribe tu nombre"/>

	<label for="apellidos">Apellidos</label>
	<input type="text" name="apellidos" id="apellidos" placeholder="1r Apellido"/>

	<label for="telefono">Telefono</label>
	<input type="tel" name="telefono" id="telefono" placeholder="numero telefonico">

	<label for="email" />Email</label>
	<input type="email" name="email" id="email" placeholder="email" required />

    <label for="tipo_diseño">Tipo de construccion</label>
    	<label>
    		<input type="radio" name="tipo_diseño" value="vivienda">Vivienda
    	</label>
    	<label>
    		<input type="radio" name="tipo_diseño" value="industrial">Industrial
    	</label>
    	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label>
    		<input type="radio" name="tipo_diseño" value="comercial">Comercial
    	</label><br>

	<label for="asunto">Asunto</label>
	<input type ="text" name="asunto" id="asunto" placeholder="titular de la consulta"/>

	<label for="mensaje">Mensaje</label>
	<textarea name="mensaje" for="mensaje" placeholder="Describe brevemente lo que necesita" maxlength="500"></textarea>
	
	<input type="submit" name="enviar" value="enviar datos"/>
</form>

</body>
</html>