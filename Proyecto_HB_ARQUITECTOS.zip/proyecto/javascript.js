alert("la pagina se a cargado con exito");

document.oncontextmenu = function() {
      return false
   }
   function right(e) {
      var msg = "Click derecho esta desactivado!!! ";
      if (navigator.appName == 'Netscape' && e.which == 3) {
         alert(msg);
         return false;
      }
      else if (navigator.appName == 'Microsoft Internet Explorer' && event.button==2) {
         alert(msg);
      return false;
      }
   return true;
}
document.onmousedown = right;

function addLink() {
    var body_element = document.getElementsByTagName('body')[0];
    var selection;
    selection = window.getSelection();
    var pagelink = "<br /><br />Más información: <a href='"+document.location.href+"'>"+document.location.href+"[/url]<br />Copyright © <b>hbarquitectos.000webhostapp.com</b>";
    var copytext = selection + pagelink;
    var newdiv = document.createElement('div');
    newdiv.style.position='absolute';
    newdiv.style.left='-99999px';
    body_element.appendChild(newdiv);
    newdiv.innerHTML = copytext;
    selection.selectAllChildren(newdiv);
    window.setTimeout(function() {
    body_element.removeChild(newdiv);
    },0);
}
document.oncopy = addLink;