<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>HB ARQUITECTOS</title>
	<link rel="stylesheet" href="misestilos.css">
	<link rel="shortcut icon" href="imagenes/HB.jpg" type="img/x-icon">
	<script src="javascript.js">
	</script>
</head>

<body>
<div class="container">
	<header>
		<figure>
		<a href="index.php"><img src="imagenes/HB.jpg" title="HBarquitectos" align="landscape"></a>
		</figure>
		<footer>
		<img src="imagenes/portadaf.jpeg">
		</footer>
		<h1 align="center">HB ARQUITECTOS</h1>
	</header>

		<?php require_once "menu_login.php"?>;

	<section>
 	<center>

		<?php require_once "mostrar.php"?>

	<footer id="pie">
		<a>
		<h5>HB ARQUITECTOS&nbsp;&nbsp;&nbsp;DISEÑO,ARQUITECTURA Y CONSTRUCCIÓN &nbsp;&nbsp;&nbsp;© 2019</h5>&nbsp;&nbsp;&nbsp;&nbsp;</a>
	</footer>
</div>
</body>
</html>