<?php
include "con_db.php";

session_start();

if (!empty($_POST)) {
    $usuario   = mysqli_real_escape_string($conex, $_POST['correo']);
    $password  = mysqli_real_escape_string($conex, $_POST['contra']);
    $sql       = "SELECT id FROM login WHERE correo = '$usuario' AND contrasena = '$password' ";
    $resultado = $conex->query($sql);
    $rows      = $resultado->num_rows;
    if ($rows > 0) {
        $row                    = $resultado->fetch_assoc();
        $_SESSION['id_usuario'] = $row['id'];
        header("Location: admin.php");
    }
}