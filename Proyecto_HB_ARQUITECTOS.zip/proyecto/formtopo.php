<!DOCTYPE html>
<html>
<head>
	<title>TOPOGRAFIA</title>

	<link rel="stylesheet" type="text/css" href="css_formtopo.css">
	<meta charset="utf-8">
	<title>HB ARQUITECTOS</title>
	<link rel="stylesheet" href="misestilos_t.css">
	<link rel="shortcut icon" href="imagenes/HB.jpg" type="img/x-icon">
	<script src="javascript_topografia.js">
	</script>

</head>
<body>
	<?php require_once"menu.php"?>

<form action="#" target="" method="post" name="formDatosPersonales">

	<label for="nombre">Nombre y apellido</label>
	<input type="text" name="nombre" id="nombre" placeholder="Escribe tu nombre y apellido"/>

	<label for="telefono">Telefono</label>
	<input type="tel" name="telefono" id="telefono" placeholder="numero telefonico">

	<label for="email" />Email</label>
	<input type="email" name="email" id="email" placeholder="email" required />

	<label for="mensaje">Mensaje</label>
	<textarea name="mensaje" for="mensaje" placeholder="Describe brevemente lo que necesita" maxlength="500"></textarea>
	
	<input type="submit" name="enviar" value="enviar datos"/>
</form>
<?php
include("registrartopo.php");
?>

</body>
</html>