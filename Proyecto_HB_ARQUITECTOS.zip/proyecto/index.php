<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>HB ARQUITECTOS</title>
	<link rel="stylesheet" href="misestilos.css">
	<link rel="shortcut icon" href="imagenes/HB.jpg" type="img/x-icon">
	<script src="javascript.js">
	</script>
</head>
 
<body>
<div class="container">
	<header>
		<figure>
		<a href="index.php"><img src="imagenes/HB.jpg" title="HBarquitectos" align="landscape"></a>
		</figure>
		<footer>
		<img src="imagenes/portadaf.jpeg">
		</footer>
		<h1 align="center">HB ARQUITECTOS</h1>
	</header>
 	
		<?php require_once"menu.php"?>
		
	<section>
	<center>
	<img src="imagenes/indexHB.jpeg" width="550" height="450">
	</center>
 	<center>
	
		<p>
			<b>HB Arquitectos nace como una iniciativa de crear un estudio de arquitectura en Santa Ana y ejercer la profesión de forma independiente.</b>
			<br>Inicialmente planteada a comienzos del 2018,  4 jóvenes arquitectos tuvieron la visión de crear e impulsar este proyecto con la idea de ofrecer un servicio integral en arquitectura y construcción.
		</p>
 
		<p>
			El nombre HB surge como una referencia a la clasificación de los lápices graduados utilizados para dibujo técnico y que son una insignia en la vida profesional del arquitecto.
			<br>
			<br>
			<big>MISION:</big>
			<br>
			<p>Somos un grupo de expertos en diseño arquitectonico e interiorismo con enfoque residencial y comercial, donde generamos soluciones creativas, autenticas e innovadoras logrando resultados que superan las expectativas de cada cliente</p>
			<br>
			<p>consolidarnos como una firma de desarrollo y ejecucuion integral de proyectos arquitectonicos a nivel local y nacional, aportando soluciones inteligentes y sustentables, que nos diferencien dentro del mercado residencial y comercial</p>
			<br>
			<br>
			<big>LOS SERVICIOS QUE OFRECEMOS SON:</big>
			<br>
				<ul>
					- <b>Topografia</b>
					<br>
					- <b>Supervicion</b>
					<br>
					- <b>Construccion</b>
					<br>
					- <b>Diseño</b>
				</ul>
				<big>¡Contactanos tambien tenemos whatsApp!</big>
			</p>
	</section>
	</center>
	<aside><img src="imagenes/wa.jpeg"></aside>
 
	<footer id="pie">
		<a>
		<h5>HB ARQUITECTOS&nbsp;&nbsp;&nbsp;DISEÑO,ARQUITECTURA Y CONSTRUCCIÓN &nbsp;&nbsp;&nbsp;© 2019</h5>&nbsp;&nbsp;&nbsp;&nbsp;</a><a href="https://www.facebook.com/HBarquitectos.sv/"><img src="imagenes/face.png" height="40" width="40"></a><a>&nbsp;&nbsp;&nbsp;&nbsp;
		</a><a href="https://www.instagram.com/hb_arquitectos.sv/"><img src="imagenes/insta.jpeg" height="40" width="40"></a></footer><a href="https://www.instagram.com/hb_arquitectos.sv/">
	</footer>
</div>
</body>
</html>