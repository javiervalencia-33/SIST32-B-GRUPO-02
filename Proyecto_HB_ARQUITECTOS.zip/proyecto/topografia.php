<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>HB ARQUITECTOS</title>
	<link rel="stylesheet" href="misestilos_t.css">
	<link rel="shortcut icon" href="imagenes/HB.jpg" type="img/x-icon">
	<script src="javascript_topografia.js">
	</script>
	<link rel="stylesheet" type="text/css" href="buttonform.css">
</head>

<body>
	<div id="agrupar">
		
<header>
		<figure>
		<a href="index.html"><img src="imagenes/HB.jpg" title="HBarquitectos" width="100%" align="landscape"></a>
		<br>
		<br>
		<img src="imagenes/portadaf.jpeg" width="100%" class="img2">
		</figure>
	</header>

<?php require_once"menu.php"?>

	  <br>
	      <div class="slider">
	          <ul id="links">
	             <li><img src="imagenes/top12.jpg" height="300" width="400"></li>
	             <li><img src="imagenes/topografia5.jpg" height="300" width="400"></li>
	             <li><img src="imagenes/topog.jpg" height="300" width="400"></li>
	             <li><img src="imagenes/tecno-top.jpg" height="300" width="400"></li>
	          </ul>
        </div>
			
				<h1>TOPOGRAF&Iacute;A</h1>
		
			<section>
	<center>
	<img src="imagenes/topo.jpeg" width="500" height="400">
	</center>
 	<center>
	
		<p>
			<b>No permitas que te roben espacios en tus propiedades, contamos con el equipo y el personal calificado para cualquier necesidad topogr&aacute;fica que se te presente.</b>
			<br>
			<br>
			<big> SERVICIOS DE TOPOGRAF&Iacute;A QUE OFRECEMOS:</big>
			<br>
				
					- <b>Levantamientos topogr&aacute;ficos</b>
					<br>
					- <b>Remedicion de areas</b>
					<br>
					- <b>Particiones y segregaciones</b>
					<br>
					- <b>Reuni&oacute;n de inmuebles</b>
					<br>
					<br>
					<b>HB arquitectos.</b> 
                    <b>Somos un nuevo concepto en #arquitectura , #diseño y #construcción 🚧✏📏📓📐🔨💪</b><br>
                    <br>
                    <br>
                    <a class="boton_personalizado" href="formtopo.php">SOLICITAR SERVICIO</a>
				
			</p>
    </center>
	</section>

	<aside>
	<img src="imagenes/wa.jpeg" width="100%" height="100%">
	<br>
	<br>
	<big>Cont&aacute;ctanos v&iacute;a telef&oacute;nica o WhatsApp y ases&oacute;rate con profesionales.</big> 
	<br>
	<br>
	<br>
	<big>O env&iacute;anos un correo a:&nbsp;&nbsp;&nbsp;hbarq.sv@gmail.com</big>
	</aside>
<footer id="pie">
<h5>HB_ARQUITECTOS&nbsp;&nbsp;&nbsp;DISEÑO,ARQUITECTURA Y CONSTRUCCIÓN &nbsp;&nbsp;&nbsp;&copy; 2019</h5>&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://www.facebook.com/HBarquitectos.sv/">
<img src="imagenes/face.png" height="45" width="45"></a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="https://www.instagram.com/hb_arquitectos.sv/"><img src="imagenes/insta.jpeg" height="45" width="45">
</footer>
</div>
</body>
</html>