<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>HB ARQUITECTOS</title>
	<link rel="stylesheet" href="misestilos4.css">
	<link rel="shortcut icon" href="imagenes/HB.jpg" type="img/x-icon">
	<script src="javascript.js">
	</script>
	<link rel="stylesheet" type="text/css" href="buttonform.css">
</head>
 
<body>
<div class="container">
	<header>
		<figure>
		<a href="index.html"><img src="imagenes/HB.jpg" title="HBarquitectos" align="landscape"></a>
		</figure>
		<footer>
		<img src="imagenes/portadaf.jpeg">
		</footer>
		<h1 align="center">DISEÑO</h1>
	</header>
 	
<?php require_once"menu.php"?>

	<section>
	<center>
	<img src="imagenes/diseño.jpeg" width="550" height="450">
	</center>
 	<center>
	
		<p>
			<b>Cotiza con nosotros, desde el diseño de una habitación dentro de tu hogar hasta tu oficina o negocio y dale ese plus que sin dudas resaltara de los demás .</b>
			<br>
			<br>
			<big>LOS SERVICIOS DE DISEÑO QUE OFRECEMOS SON:</big>
			<br>
				<ul>
					- <b>Interiores y exteriores</b>
					<br>
					- <b>Jardineria y paisajismo</b>
					<br>
					- <b>Adecuacion de locales comerciales y oficinas</b>
					<br>
					- <b>Maquetas 3D, produccion de renders y recorridos virtuales</b>
				</ul>
				<a class="boton_personalizado" href="contactos.php">SOLICITAR SERVICIO</a>
			</p>
	</section>
	</center>
	<aside>
		<img src="imagenes/wa.jpeg">
		<br>
	</aside>
	<footer id="pie">
		<a>
		<h5>HB ARQUITECTOS&nbsp;&nbsp;&nbsp;DISEÑO,ARQUITECTURA Y CONSTRUCCIÓN &nbsp;&nbsp;&nbsp;© 2019</h5>&nbsp;&nbsp;&nbsp;&nbsp;</a><a href="https://www.facebook.com/HBarquitectos.sv/"><img src="imagenes/face.png" height="40" width="40"></a><a>&nbsp;&nbsp;&nbsp;&nbsp;
		</a><a href="https://www.instagram.com/hb_arquitectos.sv/"><img src="imagenes/insta.jpeg" height="40" width="40"></a></footer><a href="https://www.instagram.com/hb_arquitectos.sv/">
	</footer>
</div>
</body>
</html>