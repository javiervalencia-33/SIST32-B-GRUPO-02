<?php
include("con_db.php");

if (isset($_POST['enviar'])) {
	if (strlen($_POST['nombre']) >= 1 &&
		strlen($_POST['telefono']) >= 1 &&
		strlen($_POST['email']) >= 1 &&
		strlen($_POST['mensaje']) >= 1) {
		$nombre = trim($_POST['nombre']);
		$telefono = trim($_POST['telefono']);
		$email = trim($_POST['email']);
		$mensaje = trim($_POST['mensaje']);
		$fechareg = date("d/m/y");
		$consulta = "INSERT INTO datos(nombre, telefono, email, mensaje, fecha_registro) VALUES ('$nombre','$telefono','$email','$mensaje','$fechareg')";
		$resultado = mysqli_query($conex,$consulta);
		if ($resultado) {
			?>
			<h3 class="ok" align="center">¡Has enviado la infromacion correctamente!</h3>
			<?php
		} else {

			?>
			<h3 class="bad" align="center">¡Ups a ocurrido un error!</h3>
			<?php
		}
		}else {
			?>
			<h3 class="bad" align="center">¡Por favor complete los campos!</h3>
			<?php
}
}
?>